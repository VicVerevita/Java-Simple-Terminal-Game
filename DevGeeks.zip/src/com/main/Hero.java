package com.main;

import java.util.Random;

public class Hero {

    private int viata;
    private int putere;
    private int aparare;
    private int viteza;
    private int noroc;

    public Hero(int hp, int pw, int def, int sp, int luck) {

        viata = hp;
        putere = pw;
        aparare = def;
        viteza = sp;
        noroc = luck;

    }

    public int getAparare() {
        return aparare;
    }

    public int getNoroc() {
        return noroc;
    }

    public int getPutere() {
        return putere;
    }

    public int getViata() {
        return viata;
    }

    public int getViteza() {
        return viteza;
    }

    public void setAparare(int aparare) {
        this.aparare = aparare;
    }

    public void setNoroc(int noroc) {
        this.noroc = noroc;
    }

    public void setPutere(int putere) {
        this.putere = putere;
    }

    public void setViata(int viata) {
        this.viata = viata;
    }

    public void setViteza(int viteza) {
        this.viteza = viteza;
    }

    public int fortaDragonului() {

        return getPutere()*2;

    }



    public void afisare() {

        System.out.println("La sfarsitul acestei ture, eroul are urmatoarele atribute: ");
        System.out.println("Viata: " + getViata());
        System.out.println("Putere: " + getPutere());
        System.out.println("Aparare: " + getAparare());
        System.out.println("Viteza: " + getViteza());
        System.out.println("Noroc: " + getNoroc());

    }

}
